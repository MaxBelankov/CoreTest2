﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreTest2.Common
{
    public enum SortingDirection
    {
        Asc,
        Desc
    }
}
