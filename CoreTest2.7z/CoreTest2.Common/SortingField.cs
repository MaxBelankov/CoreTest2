﻿namespace CoreTest2.Common
{
    public enum SortingField
    {
        Id,
        Name,
        Position,
        Salary,
        EmploymentDate,
        WorkplaceNo
    }
}